<template>
	<div id="intro">GET YOUR API KEY!!!</div>
</template>
